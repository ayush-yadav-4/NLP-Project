import { type NextRequest, NextResponse } from "next/server"
import { analyzeTweets } from "@/lib/nlp-service"

export async function POST(request: NextRequest) {
  try {
    const { username, tweets } = await request.json()

    if (!username || !tweets || tweets.length === 0) {
      return NextResponse.json({ error: "Username and tweets are required" }, { status: 400 })
    }

    // Analyze custom tweets with NLP
    const analysis = await analyzeTweets(tweets, username)

    return NextResponse.json(analysis)
  } catch (error) {
    console.error("Analysis error:", error)
    return NextResponse.json({ error: "Analysis failed" }, { status: 500 })
  }
}
