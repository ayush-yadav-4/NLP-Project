// NLP Analysis Service
// This service handles tweet extraction and NLP analysis

export function extractTwitterHandle(url: string): string | null {
  try {
    const urlObj = new URL(url)
    const pathname = urlObj.pathname
    const handle = pathname.split("/").filter(Boolean)[0]

    if (handle && !handle.includes("?")) {
      return handle
    }
    return null
  } catch {
    return null
  }
}

export async function fetchTweets(handle: string): Promise<string[]> {
  // In production, integrate with Twitter API v2
  const tweetDatabase: { [key: string]: string[] } = {
    default: [
      "Just launched our new product! Excited to see how the market responds. #innovation #startup",
      "Believe in continuous learning and growth. Read 3 books this month on leadership and AI.",
      "Diversity and inclusion are core values. We're building a team that reflects our community.",
      "Work-life balance matters. Took a week off to recharge and spend time with family.",
      "Excited about the future of renewable energy. Investing in sustainable tech companies.",
      "Great discussion on ethics in AI today. We need more conversations like this.",
      "Mentoring junior developers is one of my favorite parts of the job.",
      "Open source contributions are important. Just merged a PR to help the community.",
      "Celebrating our team's achievement! Hard work and collaboration paid off.",
      "Always looking to improve. Feedback is a gift. What can we do better?",
    ],
    tech: [
      "Just shipped a major feature update. The team did amazing work on this.",
      "Exploring the latest in machine learning. The possibilities are endless.",
      "Code review best practices: be kind, be thorough, be constructive.",
      "Debugging is like detective work. Love solving complex problems.",
      "Open source is the future. Contributing to the community matters.",
      "Performance optimization is an art. Shaved 40% off load time today.",
      "Testing is not optional. Quality code requires discipline.",
      "Refactoring legacy code is challenging but rewarding.",
      "API design matters. Good documentation saves everyone time.",
      "DevOps culture is essential for modern teams.",
    ],
    business: [
      "Quarterly results exceeded expectations. Great work by the entire team.",
      "Market analysis shows strong growth potential in Q4.",
      "Strategic partnerships are key to scaling. Excited about new collaborations.",
      "Customer feedback is invaluable. Always listening to our users.",
      "Efficiency improvements led to 25% cost reduction.",
      "Building a strong company culture is our top priority.",
      "Investor confidence is high. Ready for the next phase of growth.",
      "Team expansion underway. Hiring top talent across all departments.",
      "Annual conference was a huge success. Great networking opportunities.",
      "Five-year plan is ambitious but achievable with the right team.",
    ],
    social: [
      "Proud to support local community initiatives. Making a real difference.",
      "Diversity in tech is not just important, it's essential.",
      "Women in leadership: we need more voices at the table.",
      "Climate action is everyone's responsibility.",
      "Education access should be a right, not a privilege.",
      "Mental health awareness in the workplace is crucial.",
      "Supporting underrepresented communities in tech.",
      "Volunteering this weekend at the local food bank.",
      "Equal pay for equal work. No exceptions.",
      "Inclusion means listening to all perspectives.",
    ],
  }

  const handleLower = handle.toLowerCase()
  let selectedTweets = tweetDatabase.default

  if (handleLower.includes("tech") || handleLower.includes("dev") || handleLower.includes("code")) {
    selectedTweets = tweetDatabase.tech
  } else if (handleLower.includes("business") || handleLower.includes("ceo") || handleLower.includes("founder")) {
    selectedTweets = tweetDatabase.business
  } else if (handleLower.includes("social") || handleLower.includes("impact") || handleLower.includes("community")) {
    selectedTweets = tweetDatabase.social
  }

  return selectedTweets.sort(() => Math.random() - 0.5).slice(0, 10)
}

export async function analyzeTweets(tweets: string[], handle: string) {
  // Perform NLP analysis on tweets
  const sentimentAnalysis = analyzeSentiment(tweets)
  const ideologyAnalysis = analyzeIdeology(tweets)
  const mindsetProfile = generateMindsetProfile(tweets, sentimentAnalysis, ideologyAnalysis)
  const themes = extractThemes(tweets)
  const riskFactors = identifyRiskFactors(tweets)
  const recommendation = generateRecommendation(sentimentAnalysis, ideologyAnalysis, riskFactors)
  const hirability = calculateHirability(sentimentAnalysis, ideologyAnalysis, riskFactors)

  return {
    username: handle,
    displayName: handle.charAt(0).toUpperCase() + handle.slice(1),
    tweetsAnalyzed: tweets.length,
    overallSentiment: sentimentAnalysis,
    ideology: ideologyAnalysis,
    mindsetProfile,
    topThemes: themes,
    riskFactors,
    recommendation,
    hirability,
  }
}

function analyzeSentiment(tweets: string[]): { positive: number; neutral: number; negative: number } {
  const positiveKeywords = [
    "great",
    "excellent",
    "love",
    "amazing",
    "wonderful",
    "fantastic",
    "excited",
    "happy",
    "success",
    "achievement",
  ]
  const negativeKeywords = [
    "hate",
    "terrible",
    "awful",
    "bad",
    "worst",
    "angry",
    "frustrated",
    "disappointed",
    "fail",
    "problem",
  ]

  let positive = 0
  let negative = 0
  let neutral = 0

  tweets.forEach((tweet) => {
    const lower = tweet.toLowerCase()
    const posCount = positiveKeywords.filter((kw) => lower.includes(kw)).length
    const negCount = negativeKeywords.filter((kw) => lower.includes(kw)).length

    if (posCount > negCount) positive++
    else if (negCount > posCount) negative++
    else neutral++
  })

  const total = tweets.length
  return {
    positive: Math.round((positive / total) * 100),
    neutral: Math.round((neutral / total) * 100),
    negative: Math.round((negative / total) * 100),
  }
}

function analyzeIdeology(tweets: string[]): { progressive: number; conservative: number; neutral: number } {
  const progressiveKeywords = [
    "diversity",
    "inclusion",
    "climate",
    "renewable",
    "equality",
    "social",
    "community",
    "sustainable",
    "progressive",
  ]
  const conservativeKeywords = [
    "tradition",
    "business",
    "profit",
    "efficiency",
    "market",
    "growth",
    "conservative",
    "stability",
    "proven",
  ]

  let progressive = 0
  let conservative = 0
  let neutral = 0

  tweets.forEach((tweet) => {
    const lower = tweet.toLowerCase()
    const progCount = progressiveKeywords.filter((kw) => lower.includes(kw)).length
    const consCount = conservativeKeywords.filter((kw) => lower.includes(kw)).length

    if (progCount > consCount) progressive++
    else if (consCount > progCount) conservative++
    else neutral++
  })

  const total = tweets.length
  return {
    progressive: Math.round((progressive / total) * 100),
    neutral: Math.round((neutral / total) * 100),
    conservative: Math.round((conservative / total) * 100),
  }
}

function generateMindsetProfile(
  tweets: string[],
  sentiment: { positive: number; neutral: number; negative: number },
  ideology: { progressive: number; conservative: number; neutral: number },
) {
  const allText = tweets.join(" ").toLowerCase()

  let category = "Balanced Professional"
  let description = "Shows balanced perspective with professional focus"
  let score = 65

  if (sentiment.positive > 60 && ideology.progressive > 50) {
    category = "Optimistic Innovator"
    description = "Positive outlook with progressive values. Likely to embrace change and new ideas."
    score = 85
  } else if (sentiment.positive > 60 && ideology.conservative > 50) {
    category = "Pragmatic Leader"
    description = "Positive outlook with focus on proven methods. Values stability and results."
    score = 75
  } else if (sentiment.negative > 40) {
    category = "Critical Thinker"
    description = "Tends to be critical and analytical. May challenge status quo."
    score = 55
  } else if (allText.includes("learning") || allText.includes("growth")) {
    category = "Growth-Oriented"
    description = "Focused on continuous improvement and development."
    score = 80
  }

  return { category, description, score }
}

function extractThemes(tweets: string[]): string[] {
  const themeKeywords: { [key: string]: string[] } = {
    "Technology & Innovation": ["tech", "innovation", "ai", "software", "product", "startup"],
    "Leadership & Management": ["team", "leadership", "management", "mentoring", "culture"],
    "Learning & Development": ["learning", "growth", "education", "development", "skill"],
    "Social Impact": ["community", "diversity", "inclusion", "social", "impact"],
    "Work-Life Balance": ["balance", "family", "health", "wellness", "recharge"],
    Sustainability: ["renewable", "sustainable", "environment", "climate", "green"],
  }

  const allText = tweets.join(" ").toLowerCase()
  const themes: string[] = []

  Object.entries(themeKeywords).forEach(([theme, keywords]) => {
    if (keywords.some((kw) => allText.includes(kw))) {
      themes.push(theme)
    }
  })

  return themes.slice(0, 5)
}

function identifyRiskFactors(tweets: string[]): string[] {
  const riskKeywords: { [key: string]: string[] } = {
    "Controversial statements": ["hate", "discriminat", "racist", "sexist", "offensive"],
    "Unprofessional behavior": ["drunk", "party", "inappropriate", "unprofessional"],
    "Extreme views": ["extremist", "radical", "conspiracy"],
    "Frequent negativity": ["always complain", "hate job", "toxic"],
  }

  const allText = tweets.join(" ").toLowerCase()
  const risks: string[] = []

  Object.entries(riskKeywords).forEach(([risk, keywords]) => {
    if (keywords.some((kw) => allText.includes(kw))) {
      risks.push(risk)
    }
  })

  return risks
}

function generateRecommendation(
  sentiment: { positive: number; neutral: number; negative: number },
  ideology: { progressive: number; conservative: number; neutral: number },
  riskFactors: string[],
): string {
  if (riskFactors.length > 0) {
    return `Caution recommended. Identified ${riskFactors.length} potential concern(s): ${riskFactors.join(", ")}. Consider further investigation before hiring.`
  }

  if (sentiment.positive > 70) {
    return "Strong candidate profile. Shows positive outlook, professional engagement, and growth mindset. Recommended for further consideration."
  }

  if (sentiment.positive > 50) {
    return "Good candidate profile. Demonstrates professional engagement and balanced perspective. Suitable for most roles."
  }

  return "Proceed with caution. Profile shows mixed signals. Recommend conducting additional interviews to assess cultural fit."
}

function calculateHirability(
  sentiment: { positive: number; neutral: number; negative: number },
  ideology: { progressive: number; conservative: number; neutral: number },
  riskFactors: string[],
): number {
  let score = 50

  // Sentiment impact
  score += sentiment.positive * 0.3
  score -= sentiment.negative * 0.3

  // Ideology balance (neutral is good)
  const ideologyBalance = 100 - Math.abs(ideology.progressive - ideology.conservative)
  score += ideologyBalance * 0.1

  // Risk factors
  score -= riskFactors.length * 15

  return Math.max(0, Math.min(100, Math.round(score)))
}
