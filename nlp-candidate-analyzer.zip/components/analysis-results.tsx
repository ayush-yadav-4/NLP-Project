"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Download } from "lucide-react"
import { SentimentChart } from "./sentiment-chart"
import { IdeologyRadar } from "./ideology-radar"

interface AnalysisResult {
  username: string
  displayName: string
  tweetsAnalyzed: number
  overallSentiment: {
    positive: number
    neutral: number
    negative: number
  }
  ideology: {
    progressive: number
    conservative: number
    neutral: number
  }
  mindsetProfile: {
    category: string
    description: string
    score: number
  }
  topThemes: string[]
  riskFactors: string[]
  recommendation: string
  hirability: number
}

interface AnalysisResultsProps {
  results: AnalysisResult
  onReset: () => void
}

export function AnalysisResults({ results, onReset }: AnalysisResultsProps) {
  const hireabilityColor =
    results.hirability >= 70 ? "text-green-500" : results.hirability >= 40 ? "text-yellow-500" : "text-red-500"

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-foreground mb-2">Analysis Results</h2>
          <p className="text-muted-foreground">@{results.username}</p>
        </div>
        <Button onClick={onReset} variant="outline" className="gap-2 bg-transparent">
          <ArrowLeft className="w-4 h-4" />
          New Analysis
        </Button>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card className="p-6 border-border/50 bg-card/50 backdrop-blur-sm">
          <div className="text-sm text-muted-foreground mb-2">Tweets Analyzed</div>
          <div className="text-3xl font-bold text-foreground">{results.tweetsAnalyzed}</div>
        </Card>
        <Card className="p-6 border-border/50 bg-card/50 backdrop-blur-sm">
          <div className="text-sm text-muted-foreground mb-2">Hirability Score</div>
          <div className={`text-3xl font-bold ${hireabilityColor}`}>{results.hirability}%</div>
        </Card>
        <Card className="p-6 border-border/50 bg-card/50 backdrop-blur-sm">
          <div className="text-sm text-muted-foreground mb-2">Mindset Profile</div>
          <div className="text-lg font-bold text-foreground">{results.mindsetProfile.category}</div>
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-6 border-border/50 bg-card/50 backdrop-blur-sm">
          <h3 className="text-lg font-semibold text-foreground mb-4">Sentiment Analysis</h3>
          <SentimentChart data={results.overallSentiment} />
        </Card>
        <Card className="p-6 border-border/50 bg-card/50 backdrop-blur-sm">
          <h3 className="text-lg font-semibold text-foreground mb-4">Ideology Spectrum</h3>
          <IdeologyRadar data={results.ideology} />
        </Card>
      </div>

      <Card className="p-6 border-border/50 bg-card/50 backdrop-blur-sm">
        <h3 className="text-lg font-semibold text-foreground mb-4">Mindset Profile</h3>
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">{results.mindsetProfile.category}</span>
              <span className="text-sm font-bold text-primary">{results.mindsetProfile.score}%</span>
            </div>
            <div className="w-full bg-border/30 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-primary to-accent h-2 rounded-full"
                style={{ width: `${results.mindsetProfile.score}%` }}
              />
            </div>
          </div>
          <p className="text-sm text-muted-foreground">{results.mindsetProfile.description}</p>
        </div>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-6 border-border/50 bg-card/50 backdrop-blur-sm">
          <h3 className="text-lg font-semibold text-foreground mb-4">Top Themes</h3>
          <div className="space-y-2">
            {results.topThemes.map((theme, i) => (
              <div key={i} className="flex items-center gap-2 p-2 rounded bg-background/50">
                <div className="w-2 h-2 rounded-full bg-primary" />
                <span className="text-sm text-foreground">{theme}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card className="p-6 border-border/50 bg-card/50 backdrop-blur-sm">
          <h3 className="text-lg font-semibold text-foreground mb-4">Risk Factors</h3>
          <div className="space-y-2">
            {results.riskFactors.length > 0 ? (
              results.riskFactors.map((factor, i) => (
                <div key={i} className="flex items-center gap-2 p-2 rounded bg-destructive/10">
                  <div className="w-2 h-2 rounded-full bg-destructive" />
                  <span className="text-sm text-foreground">{factor}</span>
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">No significant risk factors detected</p>
            )}
          </div>
        </Card>
      </div>

      <Card className="p-6 border-border/50 bg-gradient-to-br from-primary/10 to-accent/10 backdrop-blur-sm border-primary/20">
        <h3 className="text-lg font-semibold text-foreground mb-3">Recommendation</h3>
        <p className="text-foreground mb-4">{results.recommendation}</p>
        <Button className="gap-2 bg-primary hover:bg-primary/90">
          <Download className="w-4 h-4" />
          Download Report
        </Button>
      </Card>
    </div>
  )
}
