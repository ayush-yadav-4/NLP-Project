import { type NextRequest, NextResponse } from "next/server"
import { extractTwitterHandle, fetchTweets, analyzeTweets } from "@/lib/nlp-service"

export async function POST(request: NextRequest) {
  try {
    const { url } = await request.json()

    if (!url) {
      return NextResponse.json({ error: "URL is required" }, { status: 400 })
    }

    // Extract Twitter handle from URL
    const handle = extractTwitterHandle(url)
    if (!handle) {
      return NextResponse.json({ error: "Invalid Twitter/X URL" }, { status: 400 })
    }

    // Fetch tweets (mock data for demo)
    const tweets = await fetchTweets(handle)

    // Analyze tweets with NLP
    const analysis = await analyzeTweets(tweets, handle)

    return NextResponse.json(analysis)
  } catch (error) {
    console.error("Analysis error:", error)
    return NextResponse.json({ error: "Analysis failed" }, { status: 500 })
  }
}
